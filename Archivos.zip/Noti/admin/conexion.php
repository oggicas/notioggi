<?php
     $server_db="localhost";
     $usuario_db="root";
     $password_db="";
     $base_db="olguidb";
?>